"""
AI Modules Package
==================
This package contains various AI module integrations for the Vision Assistant.
"""

__version__ = "1.0.0"
__author__ = "Vision Assistant Team"
